Model data and observation data:
row: 8 station;
colume: 50 hour;