Model data and observation data:
row: 3 layer (surface, middle, bottom) * 8 station =24;
colume: 50 hour;